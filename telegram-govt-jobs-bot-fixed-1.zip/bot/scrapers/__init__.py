"""
Scrapers Package Initializer
"""
from .base import BaseScraper
from .drdo import DRDOScraper
from .ongc import ONGCScraper
from .rrb import RRBScraper
from .upsc import UPSCScraper
from .ntpc import NTPCScraper
from .isro import ISROScraper
from .barc import BARCScraper
from .ssc import SSCScraper
from .iocl import IOCLScraper
from .hpcl import HPCLScraper
from .bpcl import BPCLScraper
from .gail import GAILScraper
from .bhel import BHELScraper
from .bel import BELScraper
from .npcil import NPCILScraper
from .employment_news import EmploymentNewsScraper

__all__ = [
    "BaseScraper",
    "DRDOScraper",
    "ONGCScraper",
    "RRBScraper",
    "UPSCScraper",
    "NTPCScraper",
    "ISROScraper",
    "BARCScraper",
    "SSCScraper",
    "IOCLScraper",
    "HPCLScraper",
    "BPCLScraper",
    "GAILScraper",
    "BHELScraper",
    "BELScraper",
    "NPCILScraper",
    "EmploymentNewsScraper"
]
