"""
AI Powered Government Jobs Telegram Bot
"""
